"""Shared isolated settings for local unit and HTTP integration tests."""

import os
import tempfile


_temp_dir = tempfile.TemporaryDirectory(prefix="learnmate-tests-")
os.environ["DATABASE_PATH"] = os.path.join(_temp_dir.name, "test.db")
os.environ["LEARNMATE_ENV"] = "development"
os.environ["JWT_SECRET"] = "test-only-signing-key-with-enough-entropy"
os.environ["LLM_PROVIDER"] = "mock"
