import unittest

from support import _temp_dir  # noqa: F401 — ensure isolated environment is configured first
from learnmate.security import issue_token, password_hash, password_matches, read_token


class SecurityUnitTests(unittest.TestCase):
    def test_password_hash_matches_only_original_password(self):
        encoded = password_hash("Sufficiently-strong-passphrase")
        self.assertTrue(password_matches("Sufficiently-strong-passphrase", encoded))
        self.assertFalse(password_matches("different-password", encoded))

    def test_signed_token_round_trip_and_tamper_detection(self):
        token = issue_token({"sub": "learner-1", "iss": "learnmate-ai", "typ": "access", "exp": 9999999999})
        self.assertEqual(read_token(token)["sub"], "learner-1")
        pieces = token.split(".")
        pieces[1] = pieces[1][:-1] + ("A" if pieces[1][-1] != "A" else "B")
        with self.assertRaises(ValueError):
            read_token(".".join(pieces))


if __name__ == "__main__":
    unittest.main()
