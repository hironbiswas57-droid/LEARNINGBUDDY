import json
import threading
import unittest
from http.server import ThreadingHTTPServer
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from support import _temp_dir  # noqa: F401 — ensure isolated environment is configured first
from learnmate.app import Handler, create_app


class LearnMateHTTPIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        create_app()
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = "http://127.0.0.1:%d" % cls.server.server_address[1]

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)

    def call_api(self, method, path, body=None, token=None):
        data = json.dumps(body).encode("utf-8") if body is not None else None
        headers = {"Content-Type": "application/json"} if data is not None else {}
        if token:
            headers["Authorization"] = "Bearer " + token
        request = Request(self.base + path, data=data, headers=headers, method=method)
        try:
            response = urlopen(request, timeout=5)
            return response.status, json.loads(response.read().decode("utf-8"))
        except HTTPError as error:
            return error.code, json.loads(error.read().decode("utf-8"))

    def login(self):
        status, payload = self.call_api("POST", "/api/v1/auth/login", {"email": "demo@learnmate.ai", "password": "LearnMate123!"})
        self.assertEqual(status, 200)
        return payload["data"]["tokens"]["access_token"]

    def test_login_course_enrollment_and_owned_lessons(self):
        token = self.login()
        status, payload = self.call_api("GET", "/api/v1/courses", token=token)
        self.assertEqual(status, 200)
        self.assertGreaterEqual(payload["meta"]["count"], 1)
        status, _ = self.call_api("POST", "/api/v1/courses/course-python/enroll", {}, token)
        self.assertEqual(status, 201)
        status, lessons = self.call_api("GET", "/api/v1/courses/course-python/lessons", token=token)
        self.assertEqual(status, 200)
        self.assertTrue(lessons["data"])
        lesson_id = lessons["data"][0]["id"]
        status, completion = self.call_api("POST", "/api/v1/lessons/" + lesson_id + "/complete", {}, token)
        self.assertEqual(status, 200)
        self.assertEqual(completion["data"]["xp_awarded"], 25)
        status, repeat = self.call_api("POST", "/api/v1/lessons/" + lesson_id + "/complete", {}, token)
        self.assertEqual(status, 200)
        self.assertEqual(repeat["data"]["xp_awarded"], 0)

    def test_registration_gates_children_and_role_escalation(self):
        child = {"email": "child@example.com", "display_name": "Child Learner", "password": "Long-enough-password", "age_bracket": "child"}
        status, payload = self.call_api("POST", "/api/v1/auth/register", child)
        self.assertEqual(status, 403)
        self.assertEqual(payload["error"]["code"], "guardian_consent_required")
        educator = {"email": "educator@example.com", "display_name": "Educator", "password": "Long-enough-password", "age_bracket": "adult", "role": "EDUCATOR"}
        status, payload = self.call_api("POST", "/api/v1/auth/register", educator)
        self.assertEqual(status, 403)
        self.assertEqual(payload["error"]["code"], "role_assignment_restricted")

    def test_refresh_rotates_tokens(self):
        status, payload = self.call_api("POST", "/api/v1/auth/login", {"email": "demo@learnmate.ai", "password": "LearnMate123!"})
        self.assertEqual(status, 200)
        old_refresh = payload["data"]["tokens"]["refresh_token"]
        status, refreshed = self.call_api("POST", "/api/v1/auth/refresh", {"refresh_token": old_refresh})
        self.assertEqual(status, 200)
        self.assertNotEqual(refreshed["data"]["tokens"]["refresh_token"], old_refresh)
        status, rejected = self.call_api("POST", "/api/v1/auth/refresh", {"refresh_token": old_refresh})
        self.assertEqual(status, 401)
        self.assertEqual(rejected["error"]["code"], "invalid_refresh_token")

    def test_goal_tutor_and_verification_state(self):
        token = self.login()
        status, goal = self.call_api("POST", "/api/v1/goals", {"title": "Review one idea", "category": "Review"}, token)
        self.assertEqual(status, 201)
        goal_id = goal["data"]["id"]
        status, changed = self.call_api("PATCH", "/api/v1/goals/" + goal_id, {"completed": True}, token)
        self.assertEqual(status, 200)
        self.assertEqual(changed["data"]["completed"], 1)
        status, response = self.call_api("POST", "/api/v1/ai/tutor/messages", {"message": "Can you help me understand loops?"}, token)
        self.assertEqual(status, 201)
        self.assertEqual(response["data"]["verification"]["status"], "unverified")

    def test_logout_revokes_current_session(self):
        token = self.login()
        status, _ = self.call_api("POST", "/api/v1/auth/logout", {}, token)
        self.assertEqual(status, 200)
        status, _ = self.call_api("GET", "/api/v1/auth/me", token=token)
        self.assertEqual(status, 401)

    def test_dashboard_and_docs_are_served(self):
        for path, expected_type in (("/", "text/html"), ("/docs", "text/html"), ("/architecture", "text/markdown")):
            response = urlopen(self.base + path, timeout=5)
            self.assertEqual(response.status, 200)
            self.assertIn(expected_type, response.headers.get("Content-Type", ""))


if __name__ == "__main__":
    unittest.main()
