# LearnMate AI

LearnMate is a small, runnable learning companion built from the supplied system architecture. This first version combines a responsive learner dashboard with a modular, versioned Python API. It uses only the Python standard library, so it runs without installing packages.

## Run locally

Use Python 3.9 or newer:

```sh
cp .env.example .env
python3 -m learnmate
```

Open [http://127.0.0.1:8000](http://127.0.0.1:8000). The API reference is at `/docs`, and the health endpoint is `/api/v1/health`.

In development, the seeded sample learner is:

- Email: `demo@learnmate.ai`
- Password: `LearnMate123!`

The sample account is created only when `LEARNMATE_ENV=development`. It is local demonstration data, not a production account. New public registrations are limited to learner accounts. Teen and adult profiles can register; accounts for younger children are blocked until a guardian consent workflow exists.

## What works now

- Email and password registration/sign-in, signed access and refresh tokens, refresh-token rotation, session revocation, and role checks.
- SQLite migrations and relational records for identity, consent, courses, lessons, goals, focus sessions, AI conversations, assessments, collaboration, integrations, career, marketplace, notifications, and audit events.
- Learner profile preferences, age-filtered course catalog, course enrollment, lesson progress, daily goals, study sessions, and weekly activity summaries.
- Tutor/reviewer provider adapter. The local demo tutor returns a sample response clearly marked unverified. The API only marks an answer verified after a configured reviewer approves it.
- Responsive dashboard sections for Overview, My learning, Goals & plan, Focus time, AI study buddy, and My profile.
- Request validation, consistent JSON envelopes, rate limiting, safe password hashing, audit events for account creation and login, and browser security headers.

## Configure an AI provider

Set `LLM_PROVIDER` to a provider label, then configure `LLM_API_KEY`, `LLM_BASE_URL`, `LLM_MODEL`, and `REVIEWER_MODEL` in a protected environment. The adapter uses an OpenAI-compatible chat-completions API. The reviewer receives the learner question, draft, and any trusted material supplied by the caller. Until a reviewer is available and returns an approval, the API marks the answer `unverified`.

Never put production credentials in source control. For a local `.env`, keep the file private; it is ignored by Git. Outside development, startup refuses the built-in development signing secret.

## Run with Docker

Build the image, then provide a strong secret through the runtime environment:

```sh
docker build -t learnmate-ai .
docker run --rm -p 8000:8000 \
  -e JWT_SECRET='replace-with-a-long-random-secret' \
  -v learnmate-data:/app/data \
  learnmate-ai
```

The container runs as an unprivileged user and stores SQLite data in `/app/data`. Put the app behind a TLS-terminating reverse proxy for remote access.

## Verify the implementation

```sh
python3 -m unittest discover -s tests -v
```

The tests use temporary SQLite storage and the local mock tutor; they do not need network access or external credentials.

## Project map

```text
learnmate/
  app.py                 HTTP adapter, routing, validation, response envelopes
  config.py              protected environment configuration
  db.py                  SQLite connections and migration runner
  migrations/            versioned relational schema
  security.py            PBKDF2 password hashing and HS256 tokens
  seed.py                catalog and development-only sample learner
  services/
    auth.py              identity, sessions, registration, login
    learning.py          profile, course, goal, focus, progress services
    tutor.py             provider-neutral tutor and reviewer orchestration
static/                  responsive browser app
docs/                    architecture, API and integration design
tests/                   standard-library unit and integration tests
```

## Current boundary

This is a useful local MVP and foundation, not a production-ready deployment for children or regulated records. The prompt's architecture is broad; see [the architecture and roadmap](docs/architecture.md) for what is implemented, what is an adapter contract, and what remains in later phases. In particular, this build does not yet provide email/phone verification, password recovery, guardian consent, OAuth, WebSockets, a queue, RAG ingestion, child community moderation, live classroom processing, payment processing, or a full parent/educator dashboard. The focus timer records sessions; it does not block device apps.
